class TheUser {
  final String uid;
  TheUser({this.uid});
}
